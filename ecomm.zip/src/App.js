import './App.css';
import Products from './products/Products';

function App() {

  return (
    <div className="app">
      <header className="app-header container">
          <h1>ECOMMERCE WEBSITE</h1>
      </header>
        <main className='shoppingList'>

          <Products/>
          
        </main>      
    </div>
  );
}

export default App;
