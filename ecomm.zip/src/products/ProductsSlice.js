import { createAsyncThunk, createSlice } from '@reduxjs/toolkit';
import { fetchProducts } from './productsApi';



const initialState = {
    products: [],
    status: 'idle'
}

export const fetchAsync = createAsyncThunk(
    'products/fetchProduct',
    async () => {
        const response = await fetchProducts()
        console.log(response,'res')
        return response.data
    }
)

export const productsSlice = createSlice({
    name: 'products',
    initialState,
    reducers: {},
    extraReducers:(builder) => {
        builder
        .addCase(fetchAsync.pending,(state) => {
            state.status = 'loading'
        })
        .addCase(fetchAsync.fulfilled,(state,action) => {
                state.status = 'fulfilled';
                state.products = action.payload
        })
        .addCase(fetchAsync.rejected,(state,action) => {
            state.status = 'failed'
        })
    }
})

export default productsSlice.reducer;