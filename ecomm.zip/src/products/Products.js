
import React, { useEffect, useState,useReducer } from 'react'
import { useSelector, useDispatch } from 'react-redux';
import { fetchAsync } from './ProductsSlice';
import './Product.css'
import {filterReducer,initialState} from '../reducers/filterReducer';
import SideMenu from './SideMenu';
import Card from '../card/Card';
import Loader from '../loader/Loader'

const Products = () => {
    const dispatch = useDispatch();
    const {products,status} = useSelector((state) => state.product);
    const [page, setPage] = useState(1);
    const [filterState, dispatchFilter] = useReducer(filterReducer, initialState);


    useEffect(() => {
        dispatch(fetchAsync())
    }, [])


    const filteredProducts = products.filter(product => {
        return (
            (filterState.category ? product.category === filterState.category : true) &&
            (filterState.brand ? product.brand === filterState.brand : true) &&
            (product.price >= filterState.priceRange[0] && product.price <= filterState.priceRange[1]) &&
            (filterState.size ? product.size === filterState.size : true) &&
            (filterState.color ? product.color === filterState.color : true)
        )
    })


    

    const selectedPageHandler = (selectedPage) => {
        if (selectedPage >= 1 && selectedPage <= filteredProducts.length / 5 && selectedPage !== page) {
            setPage(selectedPage)
        }
    }
    return (
        <>  
            <div className='main-wrapper'>
            {status  === 'loading' || status =='idle' ? (
               <Loader/>
            ): (
                <>
                <div className='products-wrapper'>
        
                    <SideMenu filterState={filterState} dispatchFilter={dispatchFilter}/>
    
                    <div className='products-listing'>
                        {filteredProducts.length > 0 && (
                            filteredProducts.slice(page * 10 - 10, page * 10).map((product) => (
                                <Card
                                    key={product.id} 
                                    id={product.id}
                                    thumbnail={product.thumbnail}
                                    title ={product.title}
                                    price={product.price}
                                    description= {product.description}
                                    rating={product.rating}
                                />
                            ))
                        )}
                        {
                        filteredProducts.length==0 && <p>No Products</p>
                        }
                    </div>
                </div>
                <div className='pagination-wrapper'>
                    {
                            filteredProducts.length > 0 && (<div className='pagination'>
                                <span 
                                onClick={() => selectedPageHandler(page - 1)} 
                                className={page > 1 ? "" : "pagination-disable"}>◀</span>
                                {
                                    [...Array(Math.ceil(filteredProducts.length / 10))].map((_,i)=>{
                                        return <span
                                        className={page === i+1 ? "pagination-selected" : "" }
                                        onClick={()=>selectedPageHandler(i+1)}
                                        key={i+1}>{i+1}</span>
                                    })
                                } 
                                <span 
                                onClick={() => selectedPageHandler(page + 1)} 
                                className={page < Math.ceil(filteredProducts.length / 10) ? "" : "pagination-disable"}
                                >▶</span>
                            </div>
                    )}
                </div>
                </>
            )}
            </div>
        </>
    )}


export default Products
