

import React,{useState,useRef,useEffect} from 'react'

const SideMenu = ({filterState,dispatchFilter}) => {
  const [isMenuOpen,setIsMenuOpen] = useState(false);
  const menuRef = useRef(null);

  
  useEffect(() => {
    const handleClickOutside = (event) => {
      if (menuRef.current && !menuRef.current.contains(event.target)) {
        setIsMenuOpen(false);  // Close the menu
      }
    };

    document.addEventListener('mousedown', handleClickOutside);


    return () => {
      document.removeEventListener('mousedown', handleClickOutside);
    };
  }, [menuRef]);


  return (
    <>
        <button className="hamburger" onClick={()=>setIsMenuOpen(!isMenuOpen)}>&#9776;</button>
        <div  ref={menuRef} className={`side-menu ${isMenuOpen ? "open" : ""}`}>
            <h2>Filter Products</h2>

            <div>
                <h3>Category</h3>
                <select value={filterState.category}  onChange={(e) => dispatchFilter({ type: 'SET_CATEGORY', payload: e.target.value })}>
                    <option value=''> All</option>
                    <option value='electronics'>Electronics</option>
                    <option value='fashion'>Fashion</option>
                    <option value='home'>Home</option>
                </select>
            </div>
            <div>
                <h3>Brand</h3>
                <select value={filterState.brand} onChange={(e) => dispatchFilter({ type: 'SET_BRAND', payload: e.target.value })}>
                    <option value=''> All</option>
                    <option value='Brand A'>Brand 1</option>
                    <option value='Brand B'>Brand 2</option>
                    <option value='Brand C'>Brand 3</option>
                    <option value='Brand D'>Brand 4</option>

                </select>
            </div>
            <div>
                <h3>Price Range</h3>
                <input
                    type="range"
                    min="0"
                    max="100"
                    step="25"
                    value={filterState.priceRange[1]}
                
                    onChange={(e) => dispatchFilter({ type: 'SET_PRICE_RANGE', payload: [0, parseInt(e.target.value)] })}
                />
                <p> ${filterState.priceRange[1]}</p>
            </div>

            <div>
                <h4>Size</h4>
                <select value={filterState.size} 
                onChange={(e) => dispatchFilter({ type: 'SET_SIZE', payload: e.target.value })}>
                    <option value="">All</option>
                    <option value="S">Small</option>
                    <option value="M">Medium</option>
                    <option value="L">Large</option>
                </select>
            </div>


            <div>
                <h4>Color</h4>
                <select value={filterState.color} 
                onChange={(e) => dispatchFilter({ type: 'SET_COLOR', payload: e.target.value })}>
                    <option value="">All</option>
                    <option value="white">White</option>
                    <option value="orange">Orange</option>
                    <option value="blue">Blue</option>
                    <option value="green">Green</option>
        
                </select>
            </div>
        </div>
    </>
  )
}

export default SideMenu