import { useReducer } from 'react';



export const initialState = {
    category: '',
    brand: '',
    priceRange: [0, 100],
    size: '',
    color: '',
};


export const filterReducer = (state, action) => {
  switch (action.type) {
    case 'SET_CATEGORY':
      return { ...state, category: action.payload };
    case 'SET_BRAND':
      return { ...state, brand: action.payload };
    case 'SET_PRICE_RANGE':
      return { ...state, priceRange: action.payload };
    case 'SET_SIZE':
      return { ...state, size: action.payload };
    case 'SET_COLOR':
      return { ...state, color: action.payload };
    case 'RESET_FILTERS':
      return initialState;
    default:
      return state;
  }
};


