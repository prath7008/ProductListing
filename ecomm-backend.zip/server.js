const express = require('express');
const cors = require('cors');

const app = express();
app.use(cors());


const products = [
  {
    id: 1,
    title: 'Smartphone',
    description: 'A smartphone with all modern features',
    price: 99,
    thumbnail: 'https://images.pexels.com/photos/1092671/pexels-photo-1092671.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1',
    category: 'electronics',
    brand: 'Brand A',
    size: 'M',
    color: 'black',
    rating: 4
  },

  {
    id: 2,
    title: 'Smartphone',
    description: 'A smartphone that keeps you connected with blazing speed',
    price: 42,
    thumbnail: 'https://images.pexels.com/photos/607812/pexels-photo-607812.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1',
    category: 'electronics',
    brand: 'Brand B',
    size: 'L',
    color: 'black',
    rating: 3
  },
  {
    id: 3,
    title: 'Smartphone',
    description: 'A camera system that redefines mobile photography.',
    price: 69,
    thumbnail: 'https://images.pexels.com/photos/887751/pexels-photo-887751.jpeg?auto=compress&cs=tinysrgb&w=600',
    category: 'electronics',
    brand: 'Brand C',
    size: 'M',
    color: 'white',
    rating: 5
  },
  {
    id: 4,
    title: 'Laptop',
    description: 'High performance laptop',
    price: 59,
    thumbnail: 'https://images.pexels.com/photos/1006293/pexels-photo-1006293.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1',
    category: 'electronics',
    brand: 'Brand B',
    size: 'L',
    color: 'gray',
    rating: 2
  },
  {
    id: 5,
    title: 'T-Shirt',
    description: 'A classic T-shirt designed for ultimate comfort',
    price: 19,
    thumbnail: 'https://images.pexels.com/photos/12922525/pexels-photo-12922525.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1',
    category: 'fashion',
    brand: 'Brand C',
    size: 'M',
    color: 'black',
    rating: 3
  },
  {
    id: 6,
    title: 'T-Shirt',
    description: 'Comfortable cotton t-shirt',
    price: 19,
    thumbnail: 'https://images.pexels.com/photos/12820465/pexels-photo-12820465.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1',
    category: 'fashion',
    brand: 'Brand C',
    size: 'S',
    color: 'black',
    rating: 5
  },
  {
    id: 7,
    title: 'Sofa',
    description: 'Comfortable sofa for your living room',
    price: 45,
    thumbnail: 'https://images.pexels.com/photos/5425123/pexels-photo-5425123.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1',
    category: 'home',
    brand: 'Brand D',
    size: 'L',
    color: 'brown',
    rating: 3
  },
  {
    id: 8,
    title: 'Sofa',
    description: 'A sofa that blends style with unbeatable comfort.',
    price: 55,
    thumbnail: 'https://images.pexels.com/photos/4740494/pexels-photo-4740494.jpeg?auto=compress&cs=tinysrgb&w=600',
    category: 'home',
    brand: 'Brand A',
    size: 'M',
    color: 'orange',
    rating: 5
  },
  {
    id: 9,
    title: 'Sofa',
    description: 'Luxuriously soft cushions for the ultimate relaxation.',
    price: 35,
    thumbnail: 'https://images.pexels.com/photos/12474787/pexels-photo-12474787.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1',
    category: 'home',
    brand: 'Brand A',
    size: 'M',
    color: 'green',
    rating: 2
  },
  {
    id: 10,
    title: 'Sofa',
    description: 'Built for durability and long-lasting comfort',
    price: 27,
    thumbnail: 'https://images.pexels.com/photos/4857775/pexels-photo-4857775.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1',
    category: 'home',
    brand: 'Brand A',
    size: 'M',
    color: 'blue',
    rating: 4
  },
  {
    id:11,
    title: 'Sofa',
    description: 'A spacious sofa perfect for family gatherings',
    price: 45,
    thumbnail: 'https://images.pexels.com/photos/12474787/pexels-photo-12474787.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1',
    category: 'home',
    brand: 'Brand A',
    size: 'M',
    color: 'green',
    rating: 2
  },
  {
    id: 12,
    title: 'Sofa',
    description: 'Sink into comfort with this plush, cozy sofa.',
    price: 35,
    thumbnail: 'https://images.pexels.com/photos/12474787/pexels-photo-12474787.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1',
    category: 'home',
    brand: 'Brand B',
    size: 'M',
    color: 'green',
    rating: 5
  },
  {
    id: 13,
    title: 'Sofa',
    description: 'Timeless design that complements any decor',
    price: 25,
    thumbnail: 'https://images.pexels.com/photos/4112598/pexels-photo-4112598.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1',
    category: 'home',
    brand: 'Brand A',
    size: 'L',
    color: 'grey',
    rating: 3
  }
  // Add more products as needed
];

// GET route to return all products
app.get('/api/products', (req, res) => {
  res.json(products);
});

// Start the server
const PORT = process.env.PORT || 5000;
app.listen(PORT, () => {
  console.log(`Server is running on port ${PORT}`);
});
